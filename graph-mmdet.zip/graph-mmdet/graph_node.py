from skimage.segmentation import slic
from PIL import Image
import numpy as np
import nibabel as nib
import os
i = 0
train_lst = "/brain_data/dataset/ccta/train_subjects.lst"
#train_lst = "/home/zhaogangming/test.txt"
val_lst  = "/brain_data/dataset/ccta/validate_all_subjects_20200410.lst"
train_list = open(train_lst, "r")
val_list = open(val_lst, "r")
train_name = train_list.readlines()
val_name = val_list.readlines()

img_root = "/brain_data/dataset/ccta/others/crop_cardiac_zoom_256x256x256/image/"
seg_root = "/brain_data/dataset/ccta/others/crop_cardiac_zoom_256x256x256/vessel_largest/"

#"/home/zhaogangming/workspace/cvpr2021/torchseg-stage2/results_train/ccta_prior/test/ccta256_0608_ct_da-se-res-lstm3-net18_lr0.002/all"
i = 0
'''
for train_file in train_name:
    img_file = os.path.join(img_root, train_file[:-1])
    seg_file = os.path.join(seg_root, train_file[:-1])
    img_3d = nib.load(img_file+'.nii.gz')
    seg_3d = nib.load(seg_file+'.nii.gz')
    img_data = img_3d.get_data()
    seg_data = seg_3d.get_data()
    affine = img_3d.affine
    res_data = img_data * seg_data 
    segments = slic(res_data, n_segments=24000, multichannel = False, compactness=0.01, max_iter=10, sigma=0, enforce_connectivity=False, min_size_factor=0.4)#, max_size_factor=10)
    segments = np.array(segments, dtype=np.int16) #* 1.0 * 255 / segments.max()
    segments = segments * seg_data
    new_image = nib.Nifti1Image(segments, affine)
    nib.save(new_image, '/home/zhaogangming/workspace/graph_new_12_19/'+train_file[:-1]+'_seg.nii.gz')
    i = i+1
    print('-----------------train samples processing----------')
    print(len(train_name))
    print(i)

train_list.close()
i = 0
'''
for train_file in val_name:
    img_file = os.path.join(img_root, train_file[:-1])
    seg_file = os.path.join(seg_root, train_file[:-1])
    img_3d = nib.load(img_file+'.nii.gz')
    seg_3d = nib.load(seg_file+'.nii.gz')
    img_data = img_3d.get_data()
    seg_data = seg_3d.get_data()
    affine = img_3d.affine
    res_data = img_data * seg_data
    segments = slic(res_data, n_segments=24000, multichannel = False, compactness=0.01, max_iter=10, sigma=0, enforce_connectivity=False, min_size_factor=0.4)
    import pdb
    pdb.set_trace()
    segments = np.array(segments, dtype=np.int16) #* 1.0 * 255 / segments.max()
    segments = segments * seg_data
    new_image = nib.Nifti1Image(segments, affine)
    nib.save(new_image, '/home/zhaogangming/workspace/graph_new_12_19/'+train_file[:-1]+'_seg.nii.gz')
    i = i + 1
    print('-----------------test samples processing----------')
    print(len(val_name))
    print(i)
val_list.close()

